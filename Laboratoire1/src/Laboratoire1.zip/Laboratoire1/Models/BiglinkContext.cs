﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
/**
 * 
 * Yan Ha Routhier-Chevrier
 * 1473192 - laboratoire 1
 * 
 * */
namespace Laboratoire1.Models
{
    // class utilisé pour le taghelper
    public class BiglinkContext
    {
        public string link { get; set; }
        public string icon { get; set; }
        public string text { get; set; }
    }
}
